import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ExternalLink, Github, FileText, TrendingUp, Code, PenTool } from "lucide-react";

const Portfolio = () => {
  const projects = [
    {
      id: 1,
      title: "Tech Blog Content Series",
      category: "Content Writing",
      description: "A series of engaging blog posts about emerging technologies, written for a tech startup's blog. Focused on making complex topics accessible to general audiences.",
      tags: ["Content Writing", "Tech Writing", "SEO"],
      icon: <FileText className="w-6 h-6" />,
      color: "text-portfolio-purple",
      bgColor: "bg-portfolio-purple/10"
    },
    {
      id: 2,
      title: "Small Business Social Media Campaign",
      category: "Digital Marketing",
      description: "Developed and executed a 3-month social media strategy for a local business, increasing engagement by 150% and followers by 80%.",
      tags: ["Social Media", "Content Strategy", "Analytics"],
      icon: <TrendingUp className="w-6 h-6" />,
      color: "text-portfolio-blue",
      bgColor: "bg-portfolio-blue/10"
    },
    {
      id: 3,
      title: "E-book Ghostwriting Project",
      category: "Ghostwriting",
      description: "Collaborated with a business coach to ghostwrite a 50-page e-book on productivity and time management for entrepreneurs.",
      tags: ["Ghostwriting", "Business Writing", "Research"],
      icon: <PenTool className="w-6 h-6" />,
      color: "text-portfolio-teal",
      bgColor: "bg-portfolio-teal/10"
    },
    {
      id: 4,
      title: "Portfolio Website Development",
      category: "Web Development",
      description: "Built responsive portfolio websites for creative professionals using modern web technologies like React, TypeScript, and Tailwind CSS.",
      tags: ["React", "TypeScript", "Tailwind CSS", "Responsive Design"],
      icon: <Code className="w-6 h-6" />,
      color: "text-accent",
      bgColor: "bg-accent/10"
    },
    {
      id: 5,
      title: "Email Marketing Campaign",
      category: "Digital Marketing",
      description: "Created and managed email marketing campaigns for a subscription service, achieving 25% open rate and 8% click-through rate.",
      tags: ["Email Marketing", "Copywriting", "Campaign Management"],
      icon: <TrendingUp className="w-6 h-6" />,
      color: "text-portfolio-blue",
      bgColor: "bg-portfolio-blue/10"
    },
    {
      id: 6,
      title: "Landing Page Copy",
      category: "Content Writing",
      description: "Wrote compelling landing page copy for a SaaS startup, focusing on conversion optimization and clear value proposition communication.",
      tags: ["Copywriting", "Conversion Optimization", "UX Writing"],
      icon: <FileText className="w-6 h-6" />,
      color: "text-portfolio-purple",
      bgColor: "bg-portfolio-purple/10"
    }
  ];

  return (
    <section id="portfolio" className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-background to-secondary/20">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">
            My Work Examples
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Here are some examples of my work across different domains. Each project 
            demonstrates my commitment to quality and client satisfaction.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project) => (
            <Card key={project.id} className="bg-gradient-card border-0 shadow-soft hover:shadow-medium transition-all duration-300 hover:scale-105 group">
              <CardContent className="p-6">
                <div className="flex items-center gap-3 mb-4">
                  <div className={`flex items-center justify-center w-12 h-12 rounded-full ${project.bgColor}`}>
                    <span className={project.color}>
                      {project.icon}
                    </span>
                  </div>
                  <div>
                    <Badge variant="secondary" className="text-xs font-medium">
                      {project.category}
                    </Badge>
                  </div>
                </div>
                
                <h3 className="text-xl font-semibold text-foreground mb-3 group-hover:text-accent transition-colors">
                  {project.title}
                </h3>
                
                <p className="text-muted-foreground mb-4 leading-relaxed">
                  {project.description}
                </p>
                
                <div className="flex flex-wrap gap-2 mb-4">
                  {project.tags.map((tag, index) => (
                    <Badge key={index} variant="outline" className="text-xs">
                      {tag}
                    </Badge>
                  ))}
                </div>
                
                <div className="flex gap-2">
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="flex-1 text-xs hover:bg-accent hover:text-accent-foreground transition-colors"
                  >
                    <ExternalLink className="w-3 h-3 mr-1" />
                    View Details
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
        
        <div className="text-center mt-12">
          <p className="text-muted-foreground mb-6">
            Want to see more examples or discuss a project?
          </p>
          <Button 
            size="lg"
            className="bg-accent hover:bg-accent/90 text-accent-foreground"
          >
            Let's Talk About Your Project
          </Button>
        </div>
      </div>
    </section>
  );
};

export default Portfolio;