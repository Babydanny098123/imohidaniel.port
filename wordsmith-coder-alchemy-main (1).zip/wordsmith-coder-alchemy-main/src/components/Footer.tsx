import { Github, Linkedin, Mail, Heart } from "lucide-react";

const Footer = () => {
  return (
    <footer className="bg-portfolio-navy text-white py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-6xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Brand */}
          <div className="md:col-span-1">
            <h3 className="text-2xl font-bold mb-4">Imohi Daniel Emmanuel</h3>
            <p className="text-gray-300 leading-relaxed">
              Creative professional specializing in writing, marketing, and web development. 
              Let's build something amazing together.
            </p>
          </div>
          
          {/* Quick Links */}
          <div className="md:col-span-1">
            <h4 className="text-lg font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2">
              <li>
                <a href="#about" className="text-gray-300 hover:text-white transition-colors">
                  About
                </a>
              </li>
              <li>
                <a href="#skills" className="text-gray-300 hover:text-white transition-colors">
                  Skills
                </a>
              </li>
              <li>
                <a href="#services" className="text-gray-300 hover:text-white transition-colors">
                  Services
                </a>
              </li>
              <li>
                <a href="#contact" className="text-gray-300 hover:text-white transition-colors">
                  Contact
                </a>
              </li>
            </ul>
          </div>
          
          {/* Connect */}
          <div className="md:col-span-1">
            <h4 className="text-lg font-semibold mb-4">Connect With Me</h4>
            <div className="flex space-x-4 mb-4">
              <a 
                href="#" 
                className="p-3 bg-white/10 rounded-full hover:bg-white/20 transition-colors hover:scale-110 transition-transform"
              >
                <Github size={20} />
              </a>
              <a 
                href="#" 
                className="p-3 bg-white/10 rounded-full hover:bg-white/20 transition-colors hover:scale-110 transition-transform"
              >
                <Linkedin size={20} />
              </a>
              <a 
                href="#" 
                className="p-3 bg-white/10 rounded-full hover:bg-white/20 transition-colors hover:scale-110 transition-transform"
              >
                <Mail size={20} />
              </a>
            </div>
            <p className="text-gray-300 text-sm">
              Always open to new opportunities and collaborations.
            </p>
          </div>
        </div>
        
        <div className="border-t border-gray-700 mt-8 pt-8 text-center">
          <p className="text-gray-300 flex items-center justify-center gap-2">
            Made with <Heart className="w-4 h-4 text-red-400" fill="currentColor" /> by Imohi Daniel Emmanuel
          </p>
          <p className="text-gray-400 text-sm mt-2">
            © 2024 Imohi Daniel Emmanuel. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;