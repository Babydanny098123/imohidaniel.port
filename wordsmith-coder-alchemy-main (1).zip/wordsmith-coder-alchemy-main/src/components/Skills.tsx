import { Card, CardContent } from "@/components/ui/card";
import { PenTool, FileText, TrendingUp, Code } from "lucide-react";

const skills = [
  {
    icon: PenTool,
    title: "Ghost Writing",
    description: "Crafting compelling content while maintaining your unique voice and perspective.",
    level: "Beginner",
    color: "text-portfolio-purple"
  },
  {
    icon: FileText,
    title: "Content Writing",
    description: "Creating engaging, SEO-optimized content that resonates with your target audience.",
    level: "Intermediate",
    color: "text-portfolio-blue"
  },
  {
    icon: TrendingUp,
    title: "Digital Marketing",
    description: "Developing strategic campaigns to boost your online presence and engagement.",
    level: "Intermediate",
    color: "text-portfolio-teal"
  },
  {
    icon: Code,
    title: "Web Development",
    description: "Building responsive, modern websites with clean code and great user experience.",
    level: "Intermediate",
    color: "text-portfolio-navy"
  }
];

const Skills = () => {
  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 bg-secondary">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">
            My Skills & Expertise
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            A diverse skill set combining creative writing, marketing strategy, and technical development
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {skills.map((skill, index) => (
            <Card 
              key={index} 
              className="group bg-gradient-card border-0 shadow-soft hover:shadow-medium transition-all duration-300 hover:-translate-y-2"
            >
              <CardContent className="p-6 text-center">
                <div className={`inline-flex items-center justify-center w-16 h-16 rounded-full bg-secondary/50 mb-4 group-hover:scale-110 transition-transform duration-300`}>
                  <skill.icon className={`w-8 h-8 ${skill.color}`} />
                </div>
                
                <h3 className="text-xl font-semibold text-foreground mb-2">
                  {skill.title}
                </h3>
                
                <p className="text-muted-foreground mb-4 text-sm leading-relaxed">
                  {skill.description}
                </p>
                
                <span className={`inline-block px-3 py-1 rounded-full text-xs font-medium bg-accent/10 ${skill.color}`}>
                  {skill.level}
                </span>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Skills;