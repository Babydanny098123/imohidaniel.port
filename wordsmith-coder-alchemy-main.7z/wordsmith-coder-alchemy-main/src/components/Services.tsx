import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { PenTool, FileText, TrendingUp, Code, ArrowRight } from "lucide-react";

const services = [
  {
    icon: PenTool,
    title: "Ghost Writing Services",
    description: "Professional ghostwriting for blogs, articles, and web content while maintaining your unique voice and brand identity.",
    features: [
      "Blog posts & articles",
      "Web copy & content",
      "Social media content",
      "Brand voice development"
    ],
    color: "border-portfolio-purple/20 hover:border-portfolio-purple/40",
    iconColor: "text-portfolio-purple"
  },
  {
    icon: FileText,
    title: "Content Writing",
    description: "Engaging, SEO-optimized content that drives traffic and converts visitors into customers.",
    features: [
      "SEO-optimized articles",
      "Marketing copy",
      "Product descriptions",
      "Email campaigns"
    ],
    color: "border-portfolio-blue/20 hover:border-portfolio-blue/40",
    iconColor: "text-portfolio-blue"
  },
  {
    icon: TrendingUp,
    title: "Digital Marketing",
    description: "Strategic digital marketing campaigns to boost your online presence and grow your business.",
    features: [
      "Social media strategy",
      "Content marketing",
      "Brand positioning",  
      "Campaign planning"
    ],
    color: "border-portfolio-teal/20 hover:border-portfolio-teal/40",
    iconColor: "text-portfolio-teal"
  },
  {
    icon: Code,
    title: "Web Development",
    description: "Modern, responsive websites built with clean code and optimized for performance and user experience.",
    features: [
      "Responsive web design",
      "Frontend development",
      "Performance optimization",
      "User experience focus"
    ],
    color: "border-portfolio-navy/20 hover:border-portfolio-navy/40",
    iconColor: "text-portfolio-navy"
  }
];

const Services = () => {
  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 bg-secondary">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">
            Services I Offer
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Comprehensive solutions combining creativity, strategy, and technical expertise 
            to help your business grow and succeed online.
          </p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {services.map((service, index) => (
            <Card 
              key={index} 
              className={`group bg-gradient-card border-2 ${service.color} shadow-soft hover:shadow-medium transition-all duration-300 hover:-translate-y-1`}
            >
              <CardHeader className="pb-4">
                <div className="flex items-center gap-4">
                  <div className="flex items-center justify-center w-12 h-12 rounded-full bg-background/50">
                    <service.icon className={`w-6 h-6 ${service.iconColor}`} />
                  </div>
                  <CardTitle className="text-xl font-semibold text-foreground">
                    {service.title}
                  </CardTitle>
                </div>
              </CardHeader>
              
              <CardContent className="pt-0">
                <p className="text-muted-foreground mb-6 leading-relaxed">
                  {service.description}
                </p>
                
                <div className="space-y-2 mb-6">
                  {service.features.map((feature, featureIndex) => (
                    <div key={featureIndex} className="flex items-center gap-2">
                      <ArrowRight className={`w-4 h-4 ${service.iconColor}`} />
                      <span className="text-sm text-muted-foreground">{feature}</span>
                    </div>
                  ))}
                </div>
                
                <Button 
                  variant="outline" 
                  className="w-full group-hover:bg-accent/5 transition-colors"
                >
                  Learn More
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;