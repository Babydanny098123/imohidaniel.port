import { Card, CardContent } from "@/components/ui/card";
import { GraduationCap, MapPin, Calendar } from "lucide-react";

const About = () => {
  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 bg-background">
      <div className="max-w-6xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Left content */}
          <div>
            <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-6">
              About Me
            </h2>
            
            <p className="text-lg text-muted-foreground mb-6 leading-relaxed">
              I'm a passionate professional with a unique blend of creative and technical skills. 
              My journey combines the art of storytelling through writing with the precision of 
              web development and strategic digital marketing.
            </p>
            
            <p className="text-lg text-muted-foreground mb-8 leading-relaxed">
              As a beginner in ghostwriting and an aspiring content creator, I bring fresh 
              perspectives and enthusiasm to every project. My computer science background 
              gives me the technical foundation to understand and solve complex problems.
            </p>
            
            <div className="flex flex-wrap gap-4">
              <div className="flex items-center gap-2 text-portfolio-purple">
                <span className="w-2 h-2 bg-portfolio-purple rounded-full"></span>
                <span className="text-sm font-medium">Creative Writing</span>
              </div>
              <div className="flex items-center gap-2 text-portfolio-blue">
                <span className="w-2 h-2 bg-portfolio-blue rounded-full"></span>
                <span className="text-sm font-medium">Technical Skills</span>
              </div>
              <div className="flex items-center gap-2 text-portfolio-teal">
                <span className="w-2 h-2 bg-portfolio-teal rounded-full"></span>
                <span className="text-sm font-medium">Strategic Thinking</span>
              </div>
            </div>
          </div>
          
          {/* Right content - Education Card */}
          <div>
            <Card className="bg-gradient-card border-0 shadow-medium">
              <CardContent className="p-8">
                <div className="flex items-center gap-4 mb-6">
                  <div className="flex items-center justify-center w-12 h-12 rounded-full bg-accent/10">
                    <GraduationCap className="w-6 h-6 text-accent" />
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold text-foreground">Education</h3>
                    <p className="text-muted-foreground">Academic Background</p>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <div className="border-l-2 border-accent/20 pl-4">
                    <h4 className="font-semibold text-foreground">Computer Science</h4>
                    <p className="text-muted-foreground mb-2">Westland Polytechnic</p>
                    
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <MapPin size={14} />
                        <span>Kenya</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Calendar size={14} />
                        <span>Graduate</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="bg-secondary/30 rounded-lg p-4 mt-6">
                    <h5 className="font-medium text-foreground mb-2">Key Competencies</h5>
                    <ul className="text-sm text-muted-foreground space-y-1">
                      <li>• Programming & Software Development</li>
                      <li>• System Analysis & Design</li>
                      <li>• Database Management</li>
                      <li>• Problem-Solving & Critical Thinking</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;