import { Button } from "@/components/ui/button";
import { ArrowDown, Github, Linkedin, Mail } from "lucide-react";
import heroImage from "@/assets/hero-bg.jpg";

const Hero = () => {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background with overlay */}
      <div className="absolute inset-0 z-0">
        <img 
          src={heroImage} 
          alt="Professional background" 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-hero opacity-90"></div>
      </div>
      
      {/* Content */}
      <div className="relative z-10 text-center text-white px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto">
        <h1 className="text-4xl sm:text-5xl lg:text-7xl font-bold mb-6 animate-fade-in">
          Imohi Daniel Emmanuel
          <span className="block text-portfolio-light-purple">Creative Professional & Developer</span>
        </h1>
        
        <p className="text-xl sm:text-2xl mb-8 text-gray-200 max-w-2xl mx-auto leading-relaxed">
          Specialized in ghostwriting, content creation, digital marketing, and web development. 
          Computer Science graduate ready to bring your ideas to life.
        </p>
        
        <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <Button 
              variant="hero" 
              size="lg"
            >
              View My Work
            </Button>
          <Button 
            variant="outline" 
            size="lg"
            className="border-white/30 text-white hover:bg-white/10 backdrop-blur-sm transition-all duration-300 hover:scale-105"
          >
            Get In Touch
          </Button>
        </div>
        
        {/* Social Links */}
        <div className="flex justify-center space-x-6 mb-8">
          <a href="#" className="text-white/80 hover:text-white transition-colors p-2 hover:scale-110 transition-transform">
            <Github size={24} />
          </a>
          <a href="#" className="text-white/80 hover:text-white transition-colors p-2 hover:scale-110 transition-transform">
            <Linkedin size={24} />
          </a>
          <a href="#" className="text-white/80 hover:text-white transition-colors p-2 hover:scale-110 transition-transform">
            <Mail size={24} />
          </a>
        </div>
        
        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
          <ArrowDown className="text-white/60" size={32} />
        </div>
      </div>
    </section>
  );
};

export default Hero;